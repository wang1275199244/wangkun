create trigger SE_TRIGGER
  before insert
  on T_SESSION
  for each row
  begin    
  select SE_SEQ.nextval into:new.SE_ID from dual;  
end;
/

