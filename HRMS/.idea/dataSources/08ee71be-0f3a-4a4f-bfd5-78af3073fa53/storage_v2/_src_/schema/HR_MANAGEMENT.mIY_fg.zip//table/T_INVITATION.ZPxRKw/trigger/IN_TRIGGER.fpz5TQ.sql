create trigger IN_TRIGGER
  before insert
  on T_INVITATION
  for each row
  begin    
  select IN_SEQ.nextval into:new.IN_ID from dual;  
end;
/

