create trigger C_TRIGGER
  before insert
  on T_CLOCK_IN
  for each row
  begin    
  select C_SEQ.nextval into:new.C_ID from dual;  
end;
/

