create trigger JA_TRIGGER
  before insert
  on T_JOB_APPLICATION
  for each row
  begin    
  select JA_SEQ.nextval into:new.JA_ID from dual;  
end;
/

