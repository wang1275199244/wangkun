create trigger V_TRIGGER
  before insert
  on T_VISITOR
  for each row
  begin    
  select V_SEQ.nextval into:new.V_ID from dual;  
end;
/

