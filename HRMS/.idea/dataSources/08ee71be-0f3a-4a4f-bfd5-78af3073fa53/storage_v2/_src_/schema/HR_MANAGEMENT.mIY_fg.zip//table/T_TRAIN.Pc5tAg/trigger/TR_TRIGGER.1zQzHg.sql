create trigger TR_TRIGGER
  before insert
  on T_TRAIN
  for each row
  begin    
  select TR_SEQ.nextval into:new.TR_ID from dual;  
end;
/

