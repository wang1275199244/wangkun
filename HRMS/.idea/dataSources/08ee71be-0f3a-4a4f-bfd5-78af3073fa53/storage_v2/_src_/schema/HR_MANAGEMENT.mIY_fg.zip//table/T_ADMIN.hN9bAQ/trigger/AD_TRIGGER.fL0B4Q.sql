create trigger AD_TRIGGER
  before insert
  on T_ADMIN
  for each row
  begin    
  select AD_SEQ.nextval into:new.AD_ID from dual;  
end;
/

