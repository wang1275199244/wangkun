create trigger R_TRIGGER
  before insert
  on T_RESUME
  for each row
  begin    
  select R_SEQ.nextval into:new.R_ID from dual;  
end;
/

