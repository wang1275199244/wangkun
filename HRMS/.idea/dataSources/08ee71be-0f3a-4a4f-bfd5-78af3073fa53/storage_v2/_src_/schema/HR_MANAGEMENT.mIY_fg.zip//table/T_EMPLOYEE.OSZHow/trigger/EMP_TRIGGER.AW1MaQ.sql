create trigger EMP_TRIGGER
  before insert
  on T_EMPLOYEE
  for each row
  begin    
  select EMP_SEQ.nextval into:new.EMP_ID from dual;  
end;
/

