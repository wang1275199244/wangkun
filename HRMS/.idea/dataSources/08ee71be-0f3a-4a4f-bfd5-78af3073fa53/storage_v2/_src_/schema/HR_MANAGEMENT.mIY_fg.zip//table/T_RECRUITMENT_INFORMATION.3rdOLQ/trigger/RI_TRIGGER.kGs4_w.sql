create trigger RI_TRIGGER
  before insert
  on T_RECRUITMENT_INFORMATION
  for each row
  begin    
  select RI_SEQ.nextval into:new.RI_ID from dual;  
end;
/

