create trigger S_TRIGGER
  before insert
  on T_SALARY
  for each row
  begin    
  select S_SEQ.nextval into:new.S_ID from dual;  
end;
/

