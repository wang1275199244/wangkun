create trigger ED_TRIGGER
  before insert
  on T_EMPLOYEE_DETAIL
  for each row
  begin    
  select ED_SEQ.nextval into:new.ED_ID from dual;  
end;
/

