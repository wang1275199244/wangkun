create trigger AR_TRIGGER
  before insert
  on T_ATTENDANCE_RECORD
  for each row
  begin    
  select AR_SEQ.nextval into:new.AR_ID from dual;  
end;
/

