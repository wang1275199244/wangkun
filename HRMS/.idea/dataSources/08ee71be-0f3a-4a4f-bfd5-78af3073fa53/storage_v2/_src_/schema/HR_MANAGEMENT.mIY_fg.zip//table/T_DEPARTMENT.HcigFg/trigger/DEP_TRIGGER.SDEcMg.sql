create trigger DEP_TRIGGER
  before insert
  on T_DEPARTMENT
  for each row
  begin    
  select DEP_SEQ.nextval into:new.DEP_ID from dual;  
end;
/

