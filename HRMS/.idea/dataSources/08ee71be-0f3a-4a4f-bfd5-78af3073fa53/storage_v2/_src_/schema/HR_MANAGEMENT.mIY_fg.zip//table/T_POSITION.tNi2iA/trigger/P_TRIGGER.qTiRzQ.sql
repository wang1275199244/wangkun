create trigger P_TRIGGER
  before insert
  on T_POSITION
  for each row
  begin    
  select P_SEQ.nextval into:new.P_ID from dual;  
end;
/

