create trigger RP_TRIGGER
  before insert
  on T_REWARD_PUNISHMENT
  for each row
  begin    
  select RP_SEQ.nextval into:new.RP_ID from dual;  
end;
/

